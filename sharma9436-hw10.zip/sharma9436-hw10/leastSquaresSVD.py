#Kartikey Sharma
import numpy as np

def lsSVD(data, tol) :
    a = data[:, :-1]
    b = data[:, -1]
    rank = np.linalg.matrix_rank(a,tol = tol)
    U,S,V = np.linalg.svd(a,full_matrices=False)
    x = np.zeros(a.shape[1])

    for i in range(0,rank):
        x += ((U[:,i].T@b)/S[i])*V[i]

    norm = np.linalg.norm(b - np.dot(a,x))
    return x, S, rank, norm

#############################  main  #############################
#
#    DO NOT CHANGE ANYTHING BELOW THIS
#
if __name__ == "__main__" :
    data = np.genfromtxt("waterUsage.csv", dtype=None, delimiter=',', skip_header=5)

    # function leastSquaresSvdStudent
    #      parameters:  2D numpy array, int
    #   return values:  1D numpy array, 1D numpy array, float
    #

    tolerance = 2.5
    x, S, r, norm = lsSVD(data, tolerance)

    print("singular values")
    print(S)

    print("\neffective rank = %d when tolerance is %.1f" % (r, tolerance))

    print("\nEstimates")
    print("    laundry = %5.1f gallons" % x[0])
    print(" dishwasher = %5.1f gallons" % x[1])
    print("     shower = %5.1f gallons" % x[2])
    print(" sprinklers = %5.1f gallons" % x[3])

    print("\nthe norm of the residual is %.1f" % norm)
