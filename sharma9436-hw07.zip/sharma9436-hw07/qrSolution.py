import numpy as np

def findX(A, b) :
    """ 
      solves systems of equations two different ways
    """
    
    m = A.transpose()
    x = m.dot(A)
    y = m.dot(b)
    
    xNormal = np.linalg.solve(x,y)
    
    
    Q,R = np.linalg.qr(A)
    QT = Q.transpose()
    qtb = QT.dot(b)
    xQR = np.linalg.solve(R,qtb)      # this is here to make the program work

    return xNormal, xQR




##########################################################
"""
    DO NOT CHANGE THE CODE BELOW

    a) you will put your logic in findX()
    b) you should look at the function calls below to get a better understanding
       of what the function receives and returns
    c) pay particular attention to the order of the model coefficients in the
       array (i.e, vector) in which they are returned
"""
if __name__ == "__main__":
    t = np.arange(10, 10.8, 0.1)
    A = np.vstack([np.ones( len(t) ), t, t**2, t**3, t**4]).T
    x = np.array([1, 1, 1, 1, 1])
    b = A @ x

    xNormal, xQR = findX(A, b)

    #  https://stackoverflow.com/questions/2891790/how-to-pretty-print-a-numpy-array-without-scientific-notation-and-with-given-pre
    with np.printoptions(precision=5, suppress=True):
        print("matrix A")
        print(A)
        print()
    
        # displays as row vector, but conceptually it is a column vector
        print()
        print("vector b")
        print(b)
    
        # displays as row vector, but conceptually it is a column vector
        print()
        print("vector x used to produce b")
        print(x)

        print()
        print("vector x found using normal equations")
        print(xNormal)

        print()
        print("x found using QR factorization")
        print(xQR)

